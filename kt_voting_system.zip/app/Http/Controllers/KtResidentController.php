<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class KtResidentController extends Controller
{
    //
}
